# ExTracker AWS Deployment Plan

## 📋 Infrastructure Overview

Based on SaveArn's proven architecture, we'll deploy ExTracker with:

### **1. AWS Services Required**

- ✅ **S3 Bucket**: Static website hosting (`extracker-s3-web`)
- ✅ **CloudFront**: CDN with SSL certificate
- ✅ **Route53**: DNS record (`extracker.rajathverse.com`)
- ✅ **Cognito User Pool**: User authentication
- ✅ **DynamoDB**: Data storage for expenses
- ✅ **API Gateway**: REST API for backend operations
- ✅ **Lambda Functions**: Serverless backend logic

### **2. What We're Changing**

#### **From localStorage → DynamoDB:**
- Currently: Data stored in browser only (lost if phone is lost)
- New: Data stored in DynamoDB (cloud backup, multi-device access)

#### **Adding Authentication:**
- Login/Signup page with Cognito
- Email verification
- Secure session management
- User-specific data isolation

---

## 🚀 Deployment Steps

### **Phase 1: Backend Infrastructure (Lambda + DynamoDB)**

We'll use **Serverless Framework** (like SaveArn) for easy deployment:

1. Create `serverless.yml` configuration
2. Define Lambda functions:
   - `addExpense`: Create new expense
   - `getExpenses`: Fetch user's expenses
   - `updateExpense`: Modify expense
   - `deleteExpense`: Remove expense
   - `getCreditCards`: Fetch credit cards
   - `addCreditCard`: Add credit card
   - etc.
3. Define DynamoDB tables:
   - `expenses-table`: Store all expense data
   - `credit-cards-table`: Store credit card data
4. Set up Cognito User Pool
5. Deploy with: `serverless deploy`

### **Phase 2: Frontend Updates**

1. Add `aws-config.js` (Cognito + API Gateway endpoints)
2. Include AWS SDK: `<script src="https://sdk.amazonaws.com/js/aws-sdk-2.1578.0.min.js"></script>`
3. Create authentication pages:
   - Login form
   - Signup form  
   - Email verification
   - Forgot password
4. Update `app.js` to use API calls instead of localStorage:
   ```javascript
   // Old: localStorage.setItem('expenseTrackerData', JSON.stringify(this.expenses))
   // New: await fetch(API_BASE_URL + '/expenses', {...})
   ```
5. Add authentication guards (redirect to login if not logged in)

### **Phase 3: S3 + CloudFront + Route53**

1. Create S3 bucket: `extracker-s3-web`
2. Enable static website hosting
3. Upload files: `index.html`, `app.js`, `styles.css`, `aws-config.js`
4. Create CloudFront distribution
5. Request/use SSL certificate
6. Create Route53 A record: `extracker.rajathverse.com`

---

## 📦 DynamoDB Table Structure

### **Table 1: `extracker-expenses`**
```
Partition Key: userId (String)
Sort Key: expenseId (String)

Attributes:
- userId: string
- expenseId: string (UUID)
- monthKey: string (e.g., "2024-11")
- category: string
- where: string
- amount: number
- dueDate: string
- isPaid: boolean
- paidAmount: number
- commitment: string
- isRecurring: boolean
- emiPaid: number
- emiTotal: number
- createdAt: timestamp
- updatedAt: timestamp
```

### **Table 2: `extracker-creditcards`**
```
Partition Key: userId (String)
Sort Key: cardId (String)

Attributes:
- userId: string
- cardId: string (UUID)
- name: string
- limit: number
- outstanding: number
- createdAt: timestamp
- updatedAt: timestamp
```

---

## 🔐 Cognito Configuration

- **User Pool**: `extracker-user-pool`
- **Attributes**: email (required), name
- **Password Policy**: Minimum 8 characters, require uppercase, number
- **Email Verification**: Required before login
- **MFA**: Optional (can be enabled later)

---

## 💰 Cost Estimate (Monthly)

Based on personal use (1-5 users):

| Service | Free Tier | Expected Cost |
|---------|-----------|---------------|
| S3 | 5GB free | ~$0.00 (< 1MB) |
| CloudFront | 1TB free | ~$0.00 |
| Route53 | $0.50/hosted zone | **$0.50** |
| Cognito | 50,000 MAU free | ~$0.00 |
| DynamoDB | 25GB free | ~$0.00 |
| Lambda | 1M requests free | ~$0.00 |
| API Gateway | 1M requests free | ~$0.00 |
| **Total** | | **~$0.50/month** |

---

## ⚡ Migration Strategy

### **Option A: Clean Start (Recommended)**
- Deploy new app with auth
- Users start fresh with login
- No data migration needed

### **Option B: Data Import**
- Add "Import from Browser" feature
- Users can upload their localStorage JSON
- One-time migration to cloud

---

## 🎯 Next Steps

1. **Confirm domain name**: `extracker.rajathverse.com` or something else?
2. **Review approach**: Do you want me to proceed with full Cognito + DynamoDB setup?
3. **Deployment method**: Should I create the serverless infrastructure files?

**Estimated Time:**
- Backend setup: 2-3 hours
- Frontend integration: 2-3 hours
- Deployment & testing: 1 hour
- **Total: ~5-7 hours**

Let me know if you want to proceed! 🚀
